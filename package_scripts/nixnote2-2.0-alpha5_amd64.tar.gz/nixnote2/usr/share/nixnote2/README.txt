NixNote:: Evernote client clone for Linux

    Copyright 2009-2014, Randy Baumgarte 
    Licensed under GNU General Public Lisence version 2

This is an incomplete clone of Evernote designed to run on Linux. 
While this is designed to work with Evernote, it is in no way
connected with or supported by Evernote.  Any problems you encounter will not be corrected by them
and, since this is GPL software, you are using this software at your own risk.  

See release.txt for details of what works and what doesn't work.

Documents:

release.txt:    Includes new features, known bugs and limitations.

changelog.txt:  ChangeLog and development history
install.txt:    Build and install instructions
credit.txt:     Credit of nixnote developers
gpl.txt:        License description of GPL v2.
license.txt:    Legal notices for licenses and trademarks

shortcut_howto.txt:  How-to document to setup shortcut keys.
shurtcut_sample.txt: Its configuration sample

